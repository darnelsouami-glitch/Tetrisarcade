package com.souami.tetrisarcade;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WebView view = new WebView(this);
        view.setBackgroundColor(0xFF090D1B);
        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        view.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        setContentView(view);
        view.loadUrl("file:///android_asset/index.html");
    }
}
