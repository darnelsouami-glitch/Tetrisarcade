# Tetris Arcade 2.1

Projet Android Studio minimal pour générer une APK de Tetris Arcade. Application Java avec WebView et jeu HTML local. Le meilleur score est conservé sur l'appareil.

## Compilation
- Android Gradle Plugin 8.6.1
- JDK 17
- Compile SDK 35
- Ouvrir ce dossier dans Android Studio puis lancer `assembleDebug`.

Identifiant : `com.souami.tetrisarcade`
